# Gun Mod
An example of a simple mod for Mindustry.

## Importing

Simply download this repository as a zip, then import it through the `Mods` dialog in Mindustry. Or, unzip this repo inside Mindustry's `mods/` folder.

## Mod theme

This mod's theme is "Ground Zero". Many Mindustry player know that this is no many block can use in "Ground Zero". So I made this mod. It added some weapons and blocks that can use in "Ground Zero": powerful guns, missile launcher and some crazy thing likes zip file wall(health: 100000)(<-WTF). (Sorry for bad English XDD)
My channel:
https://www.youtube.com/channel/UCIEQ8QoSxbEXXASSyL7xqjw

https://www.youtube.com/channel/UC8NsLjmsKaf3p43ASiExkRg